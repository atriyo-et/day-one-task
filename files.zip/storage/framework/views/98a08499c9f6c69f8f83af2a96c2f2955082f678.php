<?php use \App\Http\Controllers\MCQ; ?>

<?php $__env->startSection('title', 'Edit Question'); ?>
<?php $__env->startSection('content'); ?>
<form action="edit" method="POST">
    <input type="hidden" name="question_id" value="<?php echo e($questions->id); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="exampleInputEmail1">Question</label>
      <input type="text" name="question" class="form-control" placeholder="Question" value="<?php echo e($questions->question); ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Point</label>
      <input type="number" name="point" class="form-control" placeholder="Point" value="<?php echo e($questions->point); ?>">
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">Options</label>
        <?php $__currentLoopData = MCQ::getAnswer($questions->ques_num); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row p-2">
            <div class="col-md-10">
        <input class="form-control form-control-sm" type="text" name="option[]" placeholder="Options" value="<?php echo e($option->answer); ?>">
            </div>
            <div class="col-md-2">
                <select name="correct[]" class="form-control form-control-sm">
                    <option value="true" <?php echo e($option->correct=='true'?'selected':''); ?>>True</option>
                    <option value="false" <?php echo e($option->correct=='false'?'selected':''); ?>>False</option>
                </select>
            </div>
            <div class="col-md-6">
        <input class="form-control form-control-sm" type="hidden" name="option_id[]" value="<?php echo e($option->id); ?>">
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <button type="submit" class="btn btn-primary">Save</button>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mcq\resources\views/edit.blade.php ENDPATH**/ ?>