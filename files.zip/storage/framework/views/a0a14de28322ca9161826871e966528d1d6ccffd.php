
<?php $__env->startSection('title', 'Quiz Results'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-2">
    <div class="d-flex justify-content-center row">
        <div class="col-md-10 col-lg-10">
            <div class="question bg-white p-3 border-bottom">
                <div class="d-flex flex-row justify-content-between align-items-center mcq">
                    <h4>You have obtained: <span>(<?php echo e($obtained); ?> out of <?php echo e($total); ?>)</span></h4>
                </div>
                <div class="d-flex flex-row justify-content-between align-items-center p-3 bg-white text-right"><a class="btn btn-primary border-success align-items-right btn-success position-relative" href="/">Try Again</a></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mcq\resources\views/result.blade.php ENDPATH**/ ?>