<?php use \App\Http\Controllers\MCQ; ?>

<?php $__env->startSection('title', 'MCQ Quiz'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-2">
    <div class="d-flex justify-content-center row">
        <div class="col-md-10 col-lg-10">
            <form action="quiz" method="POST">
                <?php echo csrf_field(); ?>
            <div class="border">
                <div class="question bg-white p-3 border-bottom">
                    <div class="d-flex flex-row justify-content-between align-items-center mcq">
                        <h4>MCQ Quiz</h4><span>(Total Questions <?php echo e(count($questions)); ?>)</span>
                    </div>
                </div>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="question bg-white p-3 border-bottom">
                    <div class="d-flex flex-row align-items-center question-title">
                        <h3 class="text-danger">Q<?php echo e($question->ques_num); ?>.</h3>
                        <h5 class="mt-1 ml-2"><?php echo e($question->question); ?></h5>
                    </div>
                    <?php $__currentLoopData = MCQ::getAnswer($question->ques_num); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $options): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="ans ml-2">
                        <label class="radio"> <input type="radio" name="ques[<?php echo e($options->ques_id); ?>]" value="<?php echo e($options->id); ?>"> <span><?php echo e($options->answer); ?></span>
                        </label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex flex-row justify-content-between align-items-center p-3 bg-white text-right"><button class="btn btn-primary border-success align-items-right btn-success position-relative" type="submit">Submit</button></div>
            </div>
        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mcq\resources\views/index.blade.php ENDPATH**/ ?>