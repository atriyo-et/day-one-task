<?php use \App\Http\Controllers\MCQ; ?>

<?php $__env->startSection('title', 'Questions List'); ?>
<?php $__env->startSection('content'); ?>
<div class="content_box">
	<div class="left_bar">
	    <ul class=" nav-tabs--vertical nav" role="navigation">            
            <li class="nav-item">
                <a href="add" class="nav-link active" >Add New</a>
            </li>           
	    </ul>
	</div>
    <div class="right_bar ">
        <div class="tab-content ">
            <div class="tab-pane fade show active" id="questions" role="tabpanel">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>Question No.</th>
                        <th>Question</th>
                        <th>Options</th>
                        <th>Point</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($question->ques_num); ?></td>
                        <td><?php echo e($question->question); ?></td>
                        <td class="text-justify">
                            <?php if(count(MCQ::getAnswer($question->ques_num))): ?>
                                <ul>
                                <?php $__currentLoopData = MCQ::getAnswer($question->ques_num); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $options): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php if($options->correct=='true'): ?><b class="text-success"><?php echo e($options->answer); ?></b><?php else: ?> <?php echo e($options->answer); ?> <?php endif; ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                <a href="addoptions/<?php echo e($question->id); ?>">Add Options</a>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($question->point); ?></td>
                        <td nowrap><a href="edit/<?php echo e($question->id); ?>">Edit</a> / <a href="delete/<?php echo e($question->id); ?>">Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
        
	    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mcq\resources\views/list.blade.php ENDPATH**/ ?>